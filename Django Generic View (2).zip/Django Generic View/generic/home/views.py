from django.shortcuts import render
from django.views.generic import CreateView
from django.views.generic.list import ListView
from django.views.generic.edit import UpdateView 
from django.views.generic.edit import DeleteView
from .models import Customer

# Create your views here.
class index(CreateView):
    model=Customer 
    fields=['name','email','password']
    success_url='/'



class list(ListView):
    model=Customer

class update(UpdateView):
    model=Customer
    fields=['name','email','password']
    success_url='/list'


class delete(DeleteView):
    model=Customer
    success_url='/list'