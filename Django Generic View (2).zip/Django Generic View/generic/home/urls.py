from django.urls import path 
from . import views 

urlpatterns=[
    path('',views.index.as_view(),name='index'),
    path('list',views.list.as_view(),name='list'),
    path('update/<int:pk>',views.update.as_view(),name='update'),
    path('delete/<int:pk>',views.delete.as_view(),name='delete'),
]